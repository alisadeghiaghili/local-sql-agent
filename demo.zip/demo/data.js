/* Sample dataset + simulation definitions for the Local SQL Agent demo.
 * All values are SYNTHETIC and privacy-safe — generated deterministically so
 * the live demo is stable and predictable across reloads. No real data. */

"use strict";

const MONTHS = [
  "Farvardin", "Ordibehesht", "Khordad", "Tir", "Mordad", "Shahrivar",
  "Mehr", "Aban", "Azar", "Dey", "Bahman", "Esfand",
];

const RINGS = [
  "Petrochemical", "Cement", "Steel", "Electricity",
  "Agri", "Export-Kish", "Metals", "Vehicle",
];

/* Deterministic PRNG so the dataset never changes between reloads. */
function mulberry32(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* Monthly trade value per ring (Rials), Persian year 1404. */
const MONTHLY = {};
{
  const rand = mulberry32(1404);
  const base = { Petrochemical: 42, Cement: 18, Steel: 26, Electricity: 9,
                 Agri: 7, "Export-Kish": 12, Metals: 15, Vehicle: 11 };
  for (const ring of RINGS) {
    const trend = 1 + (rand() - 0.45) * 0.5; // slight drift
    MONTHLY[ring] = MONTHS.map((_, i) => {
      const wobble = 0.82 + rand() * 0.42;
      const growth = 1 + i * 0.02;
      return Math.round(base[ring] * 1e9 * trend * wobble * growth / 1e8) * 1e8;
    });
  }
}

const RING_TOTALS = RINGS.map((ring) => ({
  Ring: ring,
  TradeValue: MONTHLY[ring].reduce((a, b) => a + b, 0),
})).sort((a, b) => b.TradeValue - a.TradeValue);

const TOP_CUSTOMERS_1402 = [
  { Rank: 1, Customer: "Kian Steel Trading Co.", PurchaseValue: 8_940_000_000_000 },
  { Rank: 2, Customer: "Alborz Petrochemical JV", PurchaseValue: 7_120_000_000_000 },
  { Rank: 3, Customer: "Pars Cement Group", PurchaseValue: 5_680_000_000_000 },
  { Rank: 4, Customer: "Mehr Industrial Supplies", PurchaseValue: 4_950_000_000_000 },
  { Rank: 5, Customer: "Arya Metals Ltd.", PurchaseValue: 4_210_000_000_000 },
  { Rank: 6, Customer: "Novin Agri Exports", PurchaseValue: 3_480_000_000_000 },
  { Rank: 7, Customer: "Kish Trade Partners", PurchaseValue: 2_930_000_000_000 },
  { Rank: 8, Customer: "Sina Energy Solutions", PurchaseValue: 2_410_000_000_000 },
  { Rank: 9, Customer: "Hormoz Shipping & Trade", PurchaseValue: 1_980_000_000_000 },
  { Rank: 10, Customer: "Giti Automotive Parts", PurchaseValue: 1_540_000_000_000 },
];

const QUARTER_3 = MONTHS.slice(3, 6).map((m, i) => ({ Month: m, Value: MONTHLY.Petrochemical[3 + i] }));
const QUARTER_4 = MONTHS.slice(6, 9).map((m, i) => ({ Month: m, Value: MONTHLY.Petrochemical[6 + i] }));
const Q3_TOTAL = QUARTER_3.reduce((a, r) => a + r.Value, 0);
const Q4_TOTAL = QUARTER_4.reduce((a, r) => a + r.Value, 0);
const QOQ_CHANGE = Math.round(((Q4_TOTAL - Q3_TOTAL) / Q3_TOTAL) * 1000) / 10;

/* ── Prepared scenarios (matched by keyword scoring) ─────────────── */
const SIMULATIONS = [
  {
    key: "ring-totals-1404",
    match: ["highest sales", "highest", "sales by ring", "ring", "1404"],
    sql:
      "SELECT TOP 5 r.Name AS Ring,\n" +
      "       SUM(c.TotalPrice) AS TradeValue\n" +
      "FROM [Auction_Fact].[Contract] c\n" +
      "JOIN [Auction_Dim].[Ring] r ON c.Ring_ID = r.ID\n" +
      "JOIN [Auction_Dim].[Date] d ON c.Date_ID = d.ID\n" +
      "WHERE d.PersianYear = 1404\n" +
      "GROUP BY r.Name\n" +
      "ORDER BY TradeValue DESC",
    columns: ["Ring", "TradeValue"],
    rows: RING_TOTALS.slice(0, 5).map((r, i) => ({ Rank: i + 1, ...r })),
    insight:
      "In 1404 the Petrochemical ring led the exchange by trade value, followed by Steel and " +
      "Cement. Together the top five rings accounted for the overwhelming majority of traded " +
      "value; Petrochemical alone was roughly twice the Steel ring's total. All values are in " +
      "Iranian Rials.",
    chart: {
      mode: "bar",
      title: "Trade value by ring (1404)",
      bars: RING_TOTALS.slice(0, 5).map((r) => ({ label: r.Ring, value: r.TradeValue })),
    },
    kpis: { total: RING_TOTALS[0].TradeValue + RING_TOTALS[1].TradeValue, top: "Petrochemical", rows: 5 },
  },
  {
    key: "top-customers-1402",
    match: ["top 10 customers", "top customers", "customers", "purchase value", "برترین مشتریان", "ارزش خرید", "1402"],
    sql:
      "SELECT TOP 10 c.Name AS Customer,\n" +
      "       SUM(cc.TotalPrice) AS PurchaseValue\n" +
      "FROM [Auction_Fact].[CustomerContract] cc\n" +
      "JOIN [Auction_Dim].[Customer] c ON cc.BuyerCustomer_ID = c.ID\n" +
      "JOIN [Auction_Dim].[Date] d ON cc.Date_ID = d.ID\n" +
      "WHERE d.PersianYear = 1402\n" +
      "GROUP BY c.Name\n" +
      "ORDER BY PurchaseValue DESC",
    columns: ["Rank", "Customer", "PurchaseValue"],
    rows: TOP_CUSTOMERS_1402,
    insight:
      "The ten largest buyers of 1402 were led by Kian Steel Trading Co. and Alborz " +
      "Petrochemical JV, which together represented over a quarter of top-10 purchase value. " +
      "Industrial raw-materials buyers dominate the ranking — a signal that B2B procurement " +
      "drives exchange turnover. Values are in Iranian Rials.",
    chart: {
      mode: "bar",
      title: "Top 10 customers by purchase value (1402)",
      bars: TOP_CUSTOMERS_1402.map((c) => ({ label: c.Customer.split(" ")[0], value: c.PurchaseValue })),
    },
    kpis: { total: TOP_CUSTOMERS_1402[0].PurchaseValue + TOP_CUSTOMERS_1402[1].PurchaseValue, top: "Kian Steel", rows: 10 },
  },
  {
    key: "cement-trend",
    match: ["cement", "trend", "month over month", "monthly"],
    sql:
      "SELECT d.PersianMonthName AS Month,\n" +
      "       SUM(c.TotalPrice) AS TradeValue\n" +
      "FROM [Auction_Fact].[Contract] c\n" +
      "JOIN [Auction_Dim].[Date] d ON c.Date_ID = d.ID\n" +
      "JOIN [Auction_Dim].[Ring] r ON c.Ring_ID = r.ID\n" +
      "WHERE r.Name = N'سيمان'\n  AND d.PersianYear = 1404\n" +
      "GROUP BY d.PersianMonthName\n" +
      "ORDER BY d.PersianMonthNumber",
    columns: ["Month", "TradeValue"],
    rows: MONTHS.map((m, i) => ({ Month: m, TradeValue: MONTHLY.Cement[i] })),
    insight:
      "Cement trades climbed steadily through 1404, with the strongest months in the second " +
      "half of the year — peak volume landed in Dey and Bahman. The ring's monthly average " +
      "grew roughly 30% from Farvardin to Esfand, consistent with a construction-heavy " +
      "demand cycle. Values are in Iranian Rials.",
    chart: {
      mode: "bar",
      title: "Cement monthly trade value (1404)",
      bars: MONTHS.map((m, i) => ({ label: m, value: MONTHLY.Cement[i] })),
    },
    kpis: { total: MONTHLY.Cement.reduce((a, b) => a + b, 0), top: "Dey / Bahman", rows: 12 },
  },
  {
    key: "qoq-comparison",
    match: ["quarter", "vs", "compared", "comparison", "quarter before"],
    sql:
      "WITH q AS (\n" +
      "  SELECT d.PersianQuarter AS Quarter, SUM(c.TotalPrice) AS Value\n" +
      "  FROM [Auction_Fact].[Contract] c\n" +
      "  JOIN [Auction_Dim].[Date] d ON c.Date_ID = d.ID\n" +
      "  WHERE d.PersianYear = 1404 AND d.PersianQuarter IN (3, 4)\n" +
      "  GROUP BY d.PersianQuarter\n" +
      ")\n" +
      "SELECT Quarter, Value,\n" +
      "       LAG(Value) OVER (ORDER BY Quarter) AS PrevQuarter,\n" +
      "       ROUND((Value - LAG(Value) OVER (ORDER BY Quarter)) * 100.0 /\n" +
      "             LAG(Value) OVER (ORDER BY Quarter), 1) AS ChangePct\n" +
      "FROM q ORDER BY Quarter",
    columns: ["Quarter", "Value", "PrevQuarter", "ChangePct"],
    rows: [
      { Quarter: "Q3 1404", Value: Q3_TOTAL, PrevQuarter: "—", ChangePct: "—" },
      { Quarter: "Q4 1404", Value: Q4_TOTAL, PrevQuarter: Q3_TOTAL, ChangePct: QOQ_CHANGE + "%" },
    ],
    insight:
      "Total trade value in Q4 1404 came in at " + fmtCompact(Q4_TOTAL) + " Rials, " +
      (QOQ_CHANGE >= 0 ? "up " : "down ") + Math.abs(QOQ_CHANGE) + "% quarter over quarter " +
      "(" + fmtCompact(Q3_TOTAL) + " Rials in Q3). The change was driven mainly by the " +
      "Petrochemical ring's volumes. Values are in Iranian Rials.",
    chart: {
      mode: "bar",
      title: "QoQ comparison (1404)",
      bars: [
        { label: "Q3 1404", value: Q3_TOTAL },
        { label: "Q4 1404", value: Q4_TOTAL },
      ],
    },
    kpis: { total: Q4_TOTAL, top: (QOQ_CHANGE >= 0 ? "+" : "") + QOQ_CHANGE + "% QoQ", rows: 2 },
  },
  {
    key: "monthly-totals",
    match: ["total", "sales", "month", "1404", "trades", "sum"],
    sql:
      "SELECT d.PersianMonthName AS Month,\n" +
      "       SUM(c.TotalPrice) AS TradeValue\n" +
      "FROM [Auction_Fact].[Contract] c\n" +
      "JOIN [Auction_Dim].[Date] d ON c.Date_ID = d.ID\n" +
      "WHERE d.PersianYear = 1404\n" +
      "GROUP BY d.PersianMonthName\n" +
      "ORDER BY d.PersianMonthNumber",
    columns: ["Month", "TradeValue"],
    rows: MONTHS.map((m, i) => ({
      Month: m,
      TradeValue: RINGS.reduce((a, ring) => a + MONTHLY[ring][i], 0),
    })),
    insight:
      "Aggregate trade value across all rings in 1404 was strongest in the autumn months, " +
      "with Mehr and Aban topping the year. Monthly totals stayed within a stable band, " +
      "showing broad-based activity across the exchange. Values are in Iranian Rials.",
    chart: {
      mode: "bar",
      title: "All-rings monthly total (1404)",
      bars: MONTHS.map((m, i) => ({
        label: m,
        value: RINGS.reduce((a, ring) => a + MONTHLY[ring][i], 0),
      })),
    },
    kpis: {
      total: RINGS.reduce((a, ring) => a + MONTHLY[ring].reduce((x, y) => x + y, 0), 0),
      top: "Mehr / Aban", rows: 12,
    },
  },
];

/* Questions that the demo treats as out-of-scope (mirrors the real API taxonomy). */
const OUT_OF_SCOPE = ["weather", "stock price", "news", "football", "هوا", "خبر"];

/* Compact Rial formatting: 4_830_000_000_000 -> "4.83T", 48_300_000_000 -> "48.3B". */
function fmtCompact(v) {
  const abs = Math.abs(v);
  if (abs >= 1e12) return (v / 1e12).toFixed(2).replace(/\.00$/, "") + "T";
  if (abs >= 1e9) return (v / 1e9).toFixed(1).replace(/\.0$/, "") + "B";
  if (abs >= 1e6) return (v / 1e6).toFixed(1).replace(/\.0$/, "") + "M";
  return String(v);
}

function fmtFull(v) {
  return v.toLocaleString("en-US");
}
