# Local SQL Agent — Web Demo

A polished, self-contained dashboard demo for the Local SQL Agent product.
Built for a live presentation: it works fully offline, needs no build step,
and never pretends a real query ran when it did not.

## Quick start

Open `index.html` in any modern browser (double-click, or serve the folder):

```powershell
# from this folder — any static server works, e.g.
python -m http.server 8080
# then open http://localhost:8080
```

Click a sample question (or type your own, English or Persian) and press **Ask**.
The five pipeline steps run with realistic timing, then the SQL, insight, chart,
KPI cards, and results table appear. The footer and banner always state whether
the run was **simulated** or **live**.

## Modes

### Simulated (default)
- Runs the prepared scenarios from `data.js` through the five pipeline steps.
- All data is synthetic and privacy-safe — generated deterministically so the
  demo is identical on every reload (ideal for rehearsing the presentation).
- The status pills, footer, and success banner explicitly say "simulated".

### Live API
- Connect to the real FastAPI backend (`/query`, `/health`).
- Enable with the **Live API** button (enter the backend URL when prompted), or
  start directly:
  `index.html?live=1&base=http://localhost:8000`
- Health pills then reflect the real `/health` probe (API · LLM · DB).
- **CORS note:** the FastAPI server (`api/server.py`) does not enable CORS, so
  cross-origin browser calls are blocked by default. To use live mode you must
  either (a) serve the demo from the same origin as the API, or (b) add
  `CORSMiddleware` to the API. If the backend is unreachable, the demo shows a
  clear error banner and you can switch back to Simulated mode — the live
  presentation is never blocked by this.

## Structure

```
demo/
├── index.html   # dashboard UI
├── style.css    # styles (matches the deck palette: navy / teal)
├── app.js       # engine: pipeline simulation, live-mode bridge, rendering
├── data.js      # sample dataset + prepared scenarios (synthetic)
└── README.md
```

## Demo storyline (5–7 minutes)

1. **Ask** — click *"Which ring had the highest sales in 1404?"*
2. **Watch the pipeline** — Understand → Generate → Validate → Execute → Interpret
3. **Read the SQL** — generated T-SQL is shown and copyable
4. **See the insight** — plain-English summary + bar chart + KPI cards
5. **Follow up** — try *"How did cement trades trend month over month?"* or the
   Persian question to show bilingual support

## Customizing

- Edit `data.js` → `SIMULATIONS` to change questions, SQL, rows, and insights.
- Edit `data.js` → `MONTHLY` to change the sample dataset.
- No external dependencies, fonts, or CDNs — safe for offline venues.
