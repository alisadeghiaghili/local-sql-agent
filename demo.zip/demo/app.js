/* Local SQL Agent — live demo engine.
 *
 * Two modes:
 *  - SIMULATED (default): runs the prepared scenarios from data.js through the
 *    five pipeline steps with realistic timing. Results are pre-loaded sample
 *    data — the UI never pretends a real query executed.
 *  - LIVE API: proxies to the FastAPI backend (/query, /health). Requires the
 *    API to allow browser calls (same-origin serving or CORS). If unreachable,
 *    the demo falls back to simulated mode with a clear notice.
 */

"use strict";

/* ── State ─────────────────────────────────────────────────────────── */
const params = new URLSearchParams(location.search);
let mode = params.get("live") === "1" ? "live" : "demo";
let baseUrl = params.get("base") || localStorage.getItem("lsa-base") || "http://localhost:8000";
let busy = false;

const $ = (id) => document.getElementById(id);
const delay = (ms) => new Promise((r) => setTimeout(r, ms));

const STEP_KEYS = ["understand", "generate", "validate", "execute", "interpret"];

/* ── Mode switch ───────────────────────────────────────────────────── */
function setMode(m) {
  mode = m;
  $("mode-demo").classList.toggle("active", m === "demo");
  $("mode-live").classList.toggle("active", m === "live");
  const foot = $("foot-mode");
  foot.textContent =
    m === "demo"
      ? "Simulated demo — results are pre-loaded sample data; no real query was executed."
      : `Live API mode — backend: ${baseUrl}. Falling back to simulated data if unreachable.`;
  if (m === "live") {
    if (!params.has("base")) promptBase();
    refreshHealth();
  } else {
    setHealth(true, true, true, "simulated");
  }
}

function promptBase() {
  const val = prompt("FastAPI backend URL (serves /query and /health):", baseUrl);
  if (val && val.trim()) {
    baseUrl = val.trim().replace(/\/+$/, "");
    localStorage.setItem("lsa-base", baseUrl);
    setMode("live");
  } else if (mode === "live") {
    setMode("demo");
  }
}

$("mode-demo").addEventListener("click", () => setMode("demo"));
$("mode-live").addEventListener("click", () => setMode("live"));

/* ── Health pills ──────────────────────────────────────────────────── */
function setHealth(api, llm, db, label) {
  const pills = { API: api, LLM: llm, DB: db };
  $("health").innerHTML = Object.entries(pills)
    .map(([name, ok]) => `<span class="pill"><span class="dot dot-${ok ? "ok" : "down"}"></span>${name}</span>`)
    .join("");
  $("health").title = label;
}

async function refreshHealth() {
  try {
    const res = await fetch(`${baseUrl}/health`, { signal: AbortSignal.timeout(4000) });
    const h = await res.json();
    setHealth(h.openai, h.database, h.database, `Live /health: ${h.status}, model ${h.model || "?"}`);
  } catch {
    setHealth(false, false, false, "Backend unreachable — run `uvicorn api.server:app` or use Simulated mode");
  }
}

/* ── Pipeline steps ────────────────────────────────────────────────── */
function resetSteps() {
  document.querySelectorAll(".step").forEach((el) => {
    el.classList.remove("running", "done", "error");
  });
}

function stepState(key, state) {
  const el = document.querySelector(`.step[data-step="${key}"]`);
  if (!el) return;
  el.classList.remove("running", "done", "error");
  if (state) el.classList.add(state);
}

async function runSteps(plan) {
  resetSteps();
  for (const [key, ms] of plan) {
    stepState(key, "running");
    await delay(ms);
    stepState(key, "done");
  }
}

/* ── Simulation selection ──────────────────────────────────────────── */
function scoreQuestion(q) {
  const tokens = q.toLowerCase();
  let best = null;
  for (const sim of SIMULATIONS) {
    const score = sim.match.reduce((n, kw) => n + (tokens.includes(kw.toLowerCase()) ? 1 : 0), 0);
    if (score > (best ? best.score : 0)) best = { sim, score };
  }
  return best ? best.sim : SIMULATIONS[SIMULATIONS.length - 1];
}

function isOutOfScope(q) {
  const t = q.toLowerCase();
  return OUT_OF_SCOPE.some((w) => t.includes(w.toLowerCase()));
}

/* ── Rendering ─────────────────────────────────────────────────────── */
function renderKPIs(kpis) {
  $("kpi-total").textContent = fmtCompact(kpis.total);
  $("kpi-rows").textContent = kpis.rows;
  $("kpi-top").textContent = kpis.top;
  $("kpi-elapsed").textContent = kpis.elapsed + " s";
}

function renderSQL(sql) {
  $("sql-code").textContent = sql;
  $("sql-card").hidden = false;
}

function renderInsight(text) {
  $("insight-text").textContent = text;
  $("insight-card").hidden = false;
}

function renderTable(columns, rows) {
  const head = $("results-head");
  const body = $("results-body");
  head.innerHTML = "";
  body.innerHTML = "";
  const tr = document.createElement("tr");
  for (const c of columns) {
    const th = document.createElement("th");
    th.textContent = c;
    tr.appendChild(th);
  }
  head.appendChild(tr);
  for (const row of rows) {
    const r = document.createElement("tr");
    for (const c of columns) {
      const td = document.createElement("td");
      const v = row[c];
      td.textContent = typeof v === "number" ? fmtFull(v) : v;
      td.dir = "auto";
      r.appendChild(td);
    }
    body.appendChild(r);
  }
  $("result-meta").textContent = `${rows.length} row${rows.length === 1 ? "" : "s"} · simulated`;
  $("results-card").hidden = false;
}

function renderChart(chart) {
  const wrap = $("chart-wrap");
  const width = Math.max(280, wrap.clientWidth - 8);
  const n = chart.bars.length;
  const barH = 20, gap = 8, labelW = 96, valW = 74, pad = 10;
  const height = pad * 2 + n * (barH + gap) + 10;
  const max = Math.max(...chart.bars.map((b) => b.value));
  const plotW = width - labelW - valW - pad * 2;

  const maxLabel = Math.max(...chart.bars.map((b) => b.label.length)) * 6.2;
  const labelWFinal = Math.min(labelW, maxLabel + 12);

  let svg = `<svg viewBox="0 0 ${width} ${height}" role="img" aria-label="${chart.title}">`;
  svg += `<text x="${pad}" y="${14}" class="chart-title-txt">${chart.title}</text>`;
  chart.bars.forEach((b, i) => {
    const y = pad + 18 + i * (barH + gap);
    const w = Math.max(4, (b.value / max) * plotW);
    const fill = i === 0 ? "#0e2a47" : "#0d9488";
    svg += `<rect class="chart-bar" x="${pad + labelWFinal}" y="${y}" width="${w}" height="${barH}" rx="4" fill="${fill}" fill-opacity="0.9"></rect>`;
    svg += `<text x="${pad}" y="${y + barH - 5}" font-size="11" fill="#64748b">${b.label}</text>`;
    svg += `<text x="${pad + labelWFinal + w + 6}" y="${y + barH - 5}" font-size="11" fill="#1f2937" font-weight="600">${fmtCompact(b.value)}</text>`;
  });
  svg += `</svg>`;
  wrap.innerHTML = svg;
  $("chart-note").textContent = "— sample data";
  $("chart-card").hidden = false;
}

function showBanner(kind, text) {
  const b = $("banner");
  b.className = "banner " + kind;
  b.textContent = text;
  b.hidden = false;
}

function clearBanner() {
  $("banner").hidden = true;
}

function resetResults() {
  ["sql-card", "insight-card", "chart-card", "results-card"].forEach((id) => {
    $(id).hidden = true;
  });
  ["kpi-total", "kpi-rows", "kpi-top", "kpi-elapsed"].forEach((id) => {
    $(id).textContent = "—";
  });
}

/* ── Simulated run ─────────────────────────────────────────────────── */
async function runSimulated(q) {
  const sim = scoreQuestion(q);
  await runSteps([
    ["understand", 320],
    ["generate", 680],
    ["validate", 380],
    ["execute", 540],
    ["interpret", 460],
  ]);
  const elapsed = (2.4 + Math.random() * 0.6).toFixed(1);
  renderSQL(sim.sql);
  renderInsight(sim.insight);
  renderChart(sim.chart);
  renderTable(sim.columns, sim.rows);
  renderKPIs({ ...sim.kpis, elapsed });
  $("result-meta").textContent = `${sim.rows.length} row${sim.rows.length === 1 ? "" : "s"} · simulated`;
  showBanner("ok", `Success — ${sim.rows.length} rows in ${elapsed}s (simulated). No real query was executed.`);
}

/* ── Live run ──────────────────────────────────────────────────────── */
async function runLive(q) {
  const t0 = performance.now();
  stepState("understand", "running");
  await delay(250);
  let res;
  try {
    res = await fetch(`${baseUrl}/query`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question: q, mode: "full", interpret: true }),
      signal: AbortSignal.timeout(60000),
    });
  } catch (err) {
    stepState("understand", "error");
    showBanner("error", `Backend unreachable (${err.name}). Switch to Simulated mode or start the API.`);
    return;
  }
  stepState("understand", "done");
  stepState("generate", "done");

  if (!res.ok) {
    let detail = `HTTP ${res.status}`;
    try {
      const j = await res.json();
      detail = j.detail || detail;
    } catch { /* keep status */ }
    stepState("validate", "error");
    showBanner("error", `Backend error: ${detail}`);
    return;
  }

  const data = await res.json();
  const elapsed = ((performance.now() - t0) / 1000).toFixed(2);
  stepState("validate", "done");
  stepState("execute", "done");

  if (data.sql) renderSQL(data.sql);
  if (data.interpretation) {
    stepState("interpret", "done");
    renderInsight(data.interpretation);
  }
  if (data.result && data.result.length) {
    const columns = Object.keys(data.result[0]);
    renderTable(columns, data.result);
    const firstNum = columns.map((c) => Number(data.result[0][c])).find((v) => Number.isFinite(v));
    renderKPIs({
      total: firstNum || 0,
      rows: data.row_count ?? data.result.length,
      top: data.result[0][columns[0]] ?? "—",
      elapsed,
    });
  }
  showBanner("ok", `Success — ${data.row_count ?? "?"} rows in ${elapsed}s · model ${data.model || "?"} · live API.`);
  $("result-meta").textContent = `${data.row_count ?? 0} rows · live API`;
}

/* ── Ask flow ──────────────────────────────────────────────────────── */
async function ask() {
  const q = $("question").value.trim();
  if (!q) {
    showBanner("error", "Please enter a question.");
    return;
  }
  if (q.length < 4) {
    showBanner("error", "Question too short — try one of the examples below.");
    return;
  }
  if (isOutOfScope(q)) {
    resetSteps();
    stepState("understand", "error");
    showBanner("error", "Out of scope (422): this question is outside the data domain.");
    return;
  }
  if (busy) return;
  busy = true;
  $("btn-ask").disabled = true;
  document.querySelectorAll(".sample").forEach((b) => (b.disabled = true));
  clearBanner();
  resetResults();

  if (mode === "live") await runLive(q);
  else await runSimulated(q);

  busy = false;
  $("btn-ask").disabled = false;
  document.querySelectorAll(".sample").forEach((b) => (b.disabled = false));
}

$("btn-ask").addEventListener("click", ask);
$("question").addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey && !e.isComposing) {
    e.preventDefault();
    ask();
  }
});
document.querySelectorAll(".sample").forEach((btn) => {
  btn.addEventListener("click", () => {
    $("question").value = btn.dataset.q;
    ask();
  });
});

$("btn-copy").addEventListener("click", async () => {
  const text = $("sql-code").textContent;
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const ta = document.createElement("textarea");
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    ta.remove();
  }
  const b = $("btn-copy");
  b.textContent = "Copied";
  setTimeout(() => (b.textContent = "Copy"), 1600);
});

/* ── Boot ──────────────────────────────────────────────────────────── */
function tickClock() {
  $("foot-time").textContent = new Date().toLocaleTimeString("en-GB");
}
setInterval(tickClock, 1000);
tickClock();
setMode(mode);
